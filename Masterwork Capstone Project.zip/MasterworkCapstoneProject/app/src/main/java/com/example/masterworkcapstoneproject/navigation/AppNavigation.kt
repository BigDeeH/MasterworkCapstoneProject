package com.example.masterworkcapstoneproject.navigation

import com.example.masterworkcapstoneproject.QuestionViewModel
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.masterworkcapstoneproject.HomeScreen
import com.example.masterworkcapstoneproject.QuizScreen
import com.example.masterworkcapstoneproject.HomeDestination
import com.example.masterworkcapstoneproject.DashboardDestination
import com.example.masterworkcapstoneproject.DashboardScreen
import com.example.masterworkcapstoneproject.QuestionViewModelFactory
import com.example.masterworkcapstoneproject.QuizDestination
import com.example.masterworkcapstoneproject.data.QuizRepository

@Composable
fun AppNavHost(
    navController: NavHostController,
    repository: QuizRepository
) {
    val questionViewModel: QuestionViewModel = viewModel(factory = QuestionViewModelFactory(repository))

    NavHost(
        navController = navController,
        startDestination = HomeDestination.route
    ) {
        composable(route = HomeDestination.route) {
            HomeScreen(
                onNavigateToDashboard = { navController.navigate(DashboardDestination.route) },
                onNavigateToQuiz = { navController.navigate(QuizDestination.route) }
            )
        }

        composable(route = DashboardDestination.route) {
            DashboardScreen(
                onNavigateToHome = { navController.navigate(HomeDestination.route) }
            )
        }

        composable(route = QuizDestination.route) {
            QuizScreen(
                onNavigateToHome = { navController.navigate(HomeDestination.route) },
                onNavigateToDashboard = { navController.navigate(DashboardDestination.route) },
                repository = repository // Pass repository or ViewModel if needed
            )
        }
    }
}
