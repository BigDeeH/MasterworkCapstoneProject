import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.Room
import android.content.Context
import com.example.masterworkcapstoneproject.data.Answer
import com.example.masterworkcapstoneproject.data.AnswerDao
import com.example.masterworkcapstoneproject.data.Question
import com.example.masterworkcapstoneproject.data.QuestionDao

@Database(entities = [Question::class, Answer::class], version = 1, exportSchema = false)
abstract class QuizDatabase : RoomDatabase() {

    abstract fun questionDao(): QuestionDao
    abstract fun answerDao(): AnswerDao

    companion object {
        @Volatile
        private var INSTANCE: QuizDatabase? = null

        fun getInstance(context: Context): QuizDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    QuizDatabase::class.java,
                    "quiz_database"
                ).fallbackToDestructiveMigration() // Optional for development
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
