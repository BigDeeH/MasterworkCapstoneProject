package com.example.masterworkcapstoneproject.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Question(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val questionText: String
)

@Entity
data class Answer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val questionId: Int,
    val answerText: String,
    val isCorrect: Boolean
)

