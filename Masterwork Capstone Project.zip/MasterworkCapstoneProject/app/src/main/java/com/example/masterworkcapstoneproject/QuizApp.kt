package com.example.masterworkcapstoneproject

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.masterworkcapstoneproject.data.QuizDatabase
import com.example.masterworkcapstoneproject.data.QuizRepository
import com.example.masterworkcapstoneproject.navigation.AppNavHost

@Composable
fun QuizApp(
    context: Context,
    navController: NavHostController = rememberNavController()
) {

    // Initialize QuizRepository
    val repository = QuizRepository(
        questionDao = QuizDatabase.getInstance(context).questionDao(),
        answerDao = QuizDatabase.getInstance(context).answerDao()
    )

    // Wrap UI in Theme

    AppNavHost(
        navController = navController,
        repository = repository // Pass the repository to AppNavHost
    )

}
