package com.example.masterworkcapstoneproject.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface AnswerDao {
    @Insert
    fun insert(answer: Answer)

    @Query("SELECT * FROM Answer WHERE questionId = :questionId")
    fun getAnswersForQuestion(questionId: Int): List<Answer>
}