package com.example.masterworkcapstoneproject

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.masterworkcapstoneproject.data.Answer
import com.example.masterworkcapstoneproject.data.Question
import com.example.masterworkcapstoneproject.data.QuizRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.util.Log

class QuestionViewModel(
    private val quizRepository: QuizRepository
) : ViewModel() {

    // State for the question list
    val questionList = mutableStateListOf<Int>()
    val savedQuestions = mutableStateListOf<Pair<String, String>>()

    // Add a new question
    fun addQuestion() {
        questionList.add(questionList.size)
    }

    // Save a question and answer to memory
    fun saveQuestionAndAnswer(question: String, answer: String) {
        if (question.isNotBlank() && answer.isNotBlank()) {
            savedQuestions.add(question to answer)
        } else {
            Log.w("QuestionViewModel", "Question or Answer is blank")
        }
    }

    // Save all questions and answers to the database
    fun saveAllToDatabase() {
        if (savedQuestions.isEmpty()) {
            Log.w("QuestionViewModel", "No questions to save")
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                savedQuestions.forEach { (question, answer) ->
                    // Create a Question entity
                    val questionEntity = Question(questionText = question)

                    // Save the question and get its ID
                    val questionId = quizRepository.saveQuestion(questionEntity) // Returns Long

                    // Create an Answer entity
                    val answerEntity = Answer(
                        questionId = questionId, // Convert Long to Int if necessary
                        answerText = answer,
                        isCorrect = true // Replace with actual logic
                    )

                    // Save the answer to the database
                    quizRepository.saveAnswer(answerEntity)
                }

                // Clear the lists after successful saving
                clearSavedQuestions()
                Log.d("QuestionViewModel", "All questions saved successfully")
            } catch (e: Exception) {
                Log.e("QuestionViewModel", "Error saving to database: ${e.message}", e)
            }
        }
    }

    // Clear all saved questions and answers
    fun clearSavedQuestions() {
        questionList.clear()
        savedQuestions.clear()
    }
}
