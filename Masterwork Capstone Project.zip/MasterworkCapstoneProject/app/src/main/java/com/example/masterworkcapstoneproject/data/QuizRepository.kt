package com.example.masterworkcapstoneproject.data

import com.example.masterworkcapstoneproject.data.Answer
import com.example.masterworkcapstoneproject.data.AnswerDao
import com.example.masterworkcapstoneproject.data.Question
import com.example.masterworkcapstoneproject.data.QuestionDao

class QuizRepository(
    private val questionDao: QuestionDao,
    private val answerDao: AnswerDao
) {
    fun saveQuestion(question: Question): Int {
        return questionDao.insert(question).toInt()
    }


    fun saveAnswer(answer: Answer) {
        answerDao.insert(answer)
    }

    fun getQuestionById(id: Int): Question {
        return questionDao.getQuestionById(id)
    }

    fun getAnswersForQuestion(questionId: Int): List<Answer> {
        return answerDao.getAnswersForQuestion(questionId)
    }
}

