package com.example.masterworkcapstoneproject

import com.example.masterworkcapstoneproject.QuestionViewModel
import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.masterworkcapstoneproject.navigation.NavigationDestination

object DashboardDestination : NavigationDestination {
    override val route = "dashboard"
    override val titleRes = R.string.dashboard
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: QuestionViewModel = viewModel(), // Get ViewModel instance
    modifier: Modifier = Modifier,
    onNavigateToHome: () -> Unit = {},
) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                title = {
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.dashboard),
                            style = MaterialTheme.typography.displaySmall,
                            color = Color.White,
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            onNavigateToHome()
                        }
                    ) {
                        Image(
                            painter = painterResource(R.drawable.baseline_home_24),
                            colorFilter = ColorFilter.tint(Color.White),
                            contentDescription = null
                        )
                    }
                },

                modifier = modifier
            )
        }
    ) { paddingValues ->
        var savedQuestions by remember { mutableStateOf(listOf<String>()) } // Replace with your actual type
        var savedAnswers by remember { mutableStateOf(listOf<String>()) }   // Replace with your actual type

        // Example usage: Display the saved questions and answers
        Column {
            savedQuestions.forEach { question ->
                Text(text = "Saved Question: $question")
            }
            savedAnswers.forEach { answer ->
                Text(text = "Saved Answer: $answer")
            }
        }
    }
}
