package com.example.masterworkcapstoneproject.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface QuestionDao {
    @Insert
    fun insert(question: Question): Long


    @Query("SELECT * FROM Question WHERE id = :id")
    fun getQuestionById(id: Int): Question

    @Query("SELECT * FROM Question")
    fun getAllQuestions(): List<Question>
}