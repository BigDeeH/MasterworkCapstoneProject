package com.example.masterworkcapstoneproject

import com.example.masterworkcapstoneproject.QuestionViewModel
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.masterworkcapstoneproject.data.QuizRepository
import com.example.masterworkcapstoneproject.navigation.NavigationDestination

object QuizDestination : NavigationDestination {
    override val route = "quiz"
    override val titleRes = R.string.quiz
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    modifier: Modifier = Modifier,
    onNavigateToHome: () -> Unit = {},
    onNavigateToDashboard: () -> Unit = {},
    repository: QuizRepository
) {
    val context = LocalContext.current
    val viewModel: QuestionViewModel = viewModel(factory = QuestionViewModelFactory(repository))

    val questionList = viewModel.questionList
    val savedQuestions = viewModel.savedQuestions

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = stringResource(R.string.quiz),
                        style = MaterialTheme.typography.displaySmall,
                        color = Color.White
                    )
                },
                actions = {
                    IconButton(onClick = { onNavigateToHome() }) {
                        Image(
                            painter = painterResource(R.drawable.baseline_home_24),
                            colorFilter = ColorFilter.tint(Color.White),
                            contentDescription = null
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Render Questions
            questionList.forEach { index ->
                Question(index) { question, answer ->
                    if (question.isNotBlank() && answer.isNotBlank()) {
                        viewModel.saveQuestionAndAnswer(question, answer)
                    } else {
                        Toast.makeText(context, "Question and Answer cannot be blank", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            // Add Question Button
            AddQuestionButton(onClick = { viewModel.addQuestion() })

            Spacer(modifier = Modifier.height(25.dp))

            // Save Button
            SaveButton(onClick = {
                if (savedQuestions.isEmpty()) {
                    Toast.makeText(context, "No questions to save!", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.saveAllToDatabase()
                    onNavigateToDashboard()
                }
            })
        }
    }
}

@Composable
fun Question(index: Int, onSave: (String, String) -> Unit) {
    var questionText by remember { mutableStateOf("") }
    var answerText by remember { mutableStateOf("") }

    Text(
        text = "Question ${index + 1}",
        fontSize = 18.sp,
        modifier = Modifier.padding(start = 16.dp)
    )

    OutlinedTextField(
        value = questionText,
        onValueChange = { questionText = it },
        label = { Text("Enter Your Question Here") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    )

    Spacer(modifier = Modifier.height(25.dp))

    Text(
        text = stringResource(R.string.response),
        fontSize = 18.sp,
        modifier = Modifier.padding(start = 16.dp)
    )

    Spacer(modifier = Modifier.height(25.dp))

    Answer(onAnswerChange = { newAnswer -> answerText = newAnswer })

    Spacer(modifier = Modifier.height(25.dp))

    onSave(questionText, answerText)
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun Answer(onAnswerChange: (String) -> Unit) {
    val responseOptions = listOf("Radio Button", "Checkbox")
    var expanded by remember { mutableStateOf(false) }
    var selectedResponse by remember { mutableStateOf(responseOptions[0]) }
    var answerText by remember { mutableStateOf("") }

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        TextField(
            value = selectedResponse,
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            responseOptions.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = {
                        selectedResponse = option
                        expanded = false
                    }
                )
            }
        }
    }

    Spacer(modifier = Modifier.height(25.dp))

    OutlinedTextField(
        value = answerText,
        onValueChange = {
            answerText = it
            onAnswerChange(it)
        },
        label = { Text("Enter Your Answer Here") },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    )
}

@Composable
fun AddQuestionButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.padding(16.dp)
    ) {
        Text(
            text = stringResource(id = R.string.add_question),
            color = Color.White,
            fontSize = 20.sp
        )
    }
}

@Composable
fun SaveButton(onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.save),
            color = Color.White,
            fontSize = 20.sp
        )
    }
}
