package com.example.masterworkcapstoneproject.data

import android.content.ClipData
import kotlinx.coroutines.flow.Flow

class OfflineQuizRepository(
    private val questionDao: QuestionDao,
    private val answerDao: AnswerDao
) {
    // Save a question
    fun saveQuestion(question: Question) {
        questionDao.insert(question)
    }

    // Save an answer
    suspend fun saveAnswer(answer: Answer) {
        answerDao.insert(answer)
    }

    // Get all questions
    suspend fun getAllQuestions(): List<Question> {
        return questionDao.getAllQuestions()
    }

    // Get all answers for a specific question
    suspend fun getAnswersForQuestion(questionId: Int): List<Answer> {
        return answerDao.getAnswersForQuestion(questionId)
    }
}
